# Сайт ООО «АльтерБелТех»

Статический сайт (HTML + CSS + немного JS). Работает на GitHub Pages без сборки.

- `config.js` — настройки: адрес обработчика заявок, телефон, почта.
- `site.js` — меню, вопросы-ответы, формы.
- `worker/` — обработчик заявок для Cloudflare (инструкция внутри).
- `privacy.html` — черновик политики конфиденциальности: перед публикацией покажите юристу.

Страницы услуг: `genpodryad`, `obshchestroitelnye-raboty`, `elektrosnabzhenie`, `ventilyaciya-vk`,
`montazh-oborudovaniya`.
